<?php
$conn = new mysqli("localhost","db_adm","db_p4ss","quick");
?>
